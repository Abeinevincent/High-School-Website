 <header id="header">
            <div class="row" style="height: 50px; background: brown; color: white; vertical-align: middle;">
                  <div class="d-none d-md-block col-md-6">    
                      <i class="fas fa-phone m-3 text-decoration-none" style="font-size: 1.01rem;"></i><span class="text-decoration-none">+256-776-852111 / +256-702-809058</span>    
                      <i class="fas fa-envelope m-3 text-decoration-none" style="font-size: 1rem;"></i> aggreyglobal@gmail.com
                  </div>
                  <div class="col-md-6">
                      <div class="typing m-3 px-3 text-center text-bold">Youre welcome to our website, scroll down to explore more!</div>
                  </div>
              </div>
        </header>